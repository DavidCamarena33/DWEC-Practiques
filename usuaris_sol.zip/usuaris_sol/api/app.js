import express from 'express'
import bcrypt from 'bcrypt'
import connection from './db.js'



const app = express()
const port = 3000

const endopoint = '/api/users'

app.use(express.json())

const requireAdmin = async (req, res, next) => {
    try {
        const { name, password } = req.body
        const [results] = await connection.query(
            'SELECT role, password FROM users WHERE name = ?',
            [name]
        )
        const passwordMatched = await bcrypt.compare(password, results[0].password);
        if (results.length === 0) {
            res.status(401).send('Usuari no autoritzat')
        } else {
            if (results[0].role === 'admin' && passwordMatched) {
                next()
            } else {
                res.status(403).send('No tens permissos')
            }
        }
    } catch (err) {
        errorHandler(err)
    }
}

app.get(endopoint, requireAdmin, async (req, res) => {
    try {
        const [results] = await connection.query(
            'SELECT name, role FROM users'
        );
        res.status(200).json(results)
    } catch (err) {
        errorHandler(err)
    }
})

app.post(endopoint, async (req, res) => {
    try {
        let { name, password, role } = req.body
        if (role != 'admin') {
            role = 'user'
        }
        const salt = await bcrypt.genSalt();
        const hashedPassword = await bcrypt.hash(password, salt);
        const [results] = await connection.query(
            'INSERT INTO users(name, password, role) VALUES(?, ?, ?)',
            [name, hashedPassword, role]
        );
        res.status(200).json(results)
    } catch (err) {
        errorHandler(err)
    }
})

const errorHandler = (err, req, res, next) => {
    console.error(err.stack)
    res.status(500).send(`Error al servidor:\n ${err}`)
}

app.listen(port, () => {
    console.log(`http://localhost:${port}${endopoint}`)
})
